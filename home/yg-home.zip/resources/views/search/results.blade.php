@extends('layouts.app')

@section('title', e($query) . ' - YGXONE Search')

@section('content')
<div class="min-h-screen bg-gray-50">
    <!-- Error Alert -->
    @if(isset($error))
    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
        <div class="flex">
            <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                </svg>
            </div>
            <div class="ml-3">
                <p class="text-sm text-red-700">{{ $error }}</p>
            </div>
        </div>
    </div>
    @endif

    <!-- Search Header -->
    <div class="bg-white border-b shadow-sm sticky top-0 z-10">
        <div class="max-w-6xl mx-auto px-4 py-4">
            <form action="/search" method="GET" class="flex gap-4 items-center">
                <a href="/" class="text-2xl font-bold tracking-tight mr-4 hidden md:block">
                    <span class="text-blue-600">Y</span>GXONE
                </a>
                <div class="flex-1 relative">
                    <input 
                        type="text" 
                        name="q" 
                        value="{{ e($query) }}"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                        placeholder="Search..."
                    >
                </div>
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
                    Search
                </button>
            </form>
        </div>
    </div>
    
    <div class="max-w-6xl mx-auto px-4 py-8">
        @if($total_results > 0)
            <p class="text-sm text-gray-600 mb-6">About {{ number_format($total_results) }} results for "{{ e($query) }}"</p>
        @else
            <p class="text-sm text-gray-600 mb-6">No results found for "{{ e($query) }}"</p>
        @endif
        
        {{-- AI Enhanced Answer --}}
        @if(isset($results['ai_enhanced']) && $results['ai_enhanced'])
        <div class="bg-gradient-to-br from-gray-50 to-blue-50 border border-blue-100 p-6 rounded-xl mb-8 relative overflow-hidden shadow-sm">
            <div class="absolute top-4 right-4 text-2xl opacity-20">✨</div>
            <h3 class="text-blue-700 font-semibold mb-3 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                </svg>
                AI-Generated Answer
            </h3>
            <p class="text-gray-700 leading-relaxed">{{ $results['ai_enhanced']['answer'] }}</p>
            
            @if(!empty($results['ai_enhanced']['sources']))
            <div class="mt-4 pt-4 border-t border-blue-100">
                <p class="text-xs text-gray-500 font-medium mb-2">Sources:</p>
                <div class="flex flex-wrap gap-2">
                    @foreach($results['ai_enhanced']['sources'] as $source)
                        @php $host = parse_url($source, PHP_URL_HOST) ?? ''; @endphp
                        @if(filter_var($source, FILTER_VALIDATE_URL) && $host)
                            <a href="{{ e($source) }}" target="_blank" rel="noopener noreferrer"
                               class="text-xs bg-white border border-gray-200 px-2 py-1 rounded text-blue-600 hover:bg-blue-50 transition-colors truncate max-w-[200px]">
                                {{ e($host) }}
                            </a>
                        @endif
                    @endforeach
                </div>
            </div>
            @endif
        </div>
        @endif

        {{-- Ecosystem Results --}}
        @if(isset($results['ecosystem']) && count($results['ecosystem']) > 0)
        <div class="mb-10">
            <h3 class="text-lg font-medium text-gray-800 mb-4 pb-2 border-b border-gray-200">Ecosystem Results</h3>
            <div class="space-y-4">
                @foreach($results['ecosystem'] as $result)
                @php
                    $ecoUrl = (str_starts_with($result['url'] ?? '', 'http://') || str_starts_with($result['url'] ?? '', 'https://'))
                        ? $result['url'] : '#';
                    
                    $badgeColors = [
                        'mail' => 'bg-red-50 text-red-600 border-red-100',
                        'drive' => 'bg-green-50 text-green-600 border-green-100',
                        'docs' => 'bg-blue-50 text-blue-600 border-blue-100',
                        'contacts' => 'bg-yellow-50 text-yellow-600 border-yellow-100',
                    ];
                    $badgeClass = $badgeColors[$result['type']] ?? 'bg-gray-50 text-gray-600 border-gray-100';
                @endphp
                <div class="bg-white p-5 rounded-lg border border-gray-200 hover:shadow-md transition-shadow duration-200">
                    <div class="flex justify-between items-start mb-2">
                        <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-bold uppercase border {{ $badgeClass }}">
                            @if(isset($result['icon']))
                                <i class="fas fa-{{ e($result['icon']) }}"></i>
                            @endif
                            {{ ucfirst(e($result['type'])) }}
                        </span>
                        @if(isset($result['metadata']['date']))
                            <span class="text-xs text-gray-400">{{ \Carbon\Carbon::parse($result['metadata']['date'])->diffForHumans() }}</span>
                        @endif
                    </div>
                    <a href="{{ e($ecoUrl) }}" class="block text-lg text-blue-700 hover:underline font-medium mb-1" rel="noopener noreferrer">
                        {{ e($result['title']) }}
                    </a>
                    <p class="text-sm text-gray-600 line-clamp-2">{{ strip_tags($result['snippet'] ?? '') }}</p>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        {{-- Web Results --}}
        <div class="space-y-6">
            @if(count($results['web']) > 0)
                <h3 class="text-lg font-medium text-gray-800 pb-2 border-b border-gray-200">Web Results</h3>
            @endif
            
            @foreach($results['web'] as $result)
            @php
                $webUrl = (str_starts_with($result['url'] ?? '', 'https://') || str_starts_with($result['url'] ?? '', 'http://'))
                    ? $result['url'] : '#';
                $favicon = filter_var($result['favicon'] ?? '', FILTER_VALIDATE_URL) ? $result['favicon'] : '';
            @endphp
            <div class="bg-white p-5 rounded-lg border border-gray-200 hover:shadow-md transition-shadow duration-200 group">
                <div class="flex items-center gap-2 mb-2 text-sm text-gray-500">
                    @if($favicon)
                        <img src="{{ e($favicon) }}" alt="" width="16" height="16" class="rounded-full" loading="lazy">
                    @endif
                    <span class="truncate">{{ e($result['domain'] ?? '') }}</span>
                </div>
                <a href="{{ e($webUrl) }}" class="block text-xl text-blue-700 group-hover:underline font-medium mb-2" target="_blank" rel="noopener noreferrer">
                    {{ e($result['title'] ?? '') }}
                </a>
                <p class="text-sm text-gray-600 leading-relaxed">
                    {{ Str::limit(strip_tags($result['snippet'] ?? ''), 200) }}
                </p>
            </div>
            @endforeach
        </div>
        
        {{-- Pagination Controls --}}
        @if(isset($pagination) && $pagination['last_page'] > 1)
        <div class="mt-8 flex justify-center">
            <nav class="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                {{-- Previous Page --}}
                @if($pagination['current_page'] > 1)
                <a href="?q={{ urlencode($query) }}&type={{ $type }}&page={{ $pagination['current_page'] - 1 }}&per_page={{ $pagination['per_page'] }}"
                   class="relative inline-flex items-center px-3 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                    </svg>
                    Previous
                </a>
                @else
                <span class="relative inline-flex items-center px-3 py-2 rounded-l-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400 cursor-not-allowed">
                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                    </svg>
                    Previous
                </span>
                @endif
                
                {{-- Page Numbers --}}
                @for($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['last_page'], $pagination['current_page'] + 2); $i++)
                    @if($i == $pagination['current_page'])
                    <span class="relative inline-flex items-center px-4 py-2 border border-blue-500 bg-blue-50 text-sm font-medium text-blue-600">
                        {{ $i }}
                    </span>
                    @else
                    <a href="?q={{ urlencode($query) }}&type={{ $type }}&page={{ $i }}&per_page={{ $pagination['per_page'] }}"
                       class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                        {{ $i }}
                    </a>
                    @endif
                @endfor
                
                {{-- Next Page --}}
                @if($pagination['has_more'])
                <a href="?q={{ urlencode($query) }}&type={{ $type }}&page={{ $pagination['current_page'] + 1 }}&per_page={{ $pagination['per_page'] }}"
                   class="relative inline-flex items-center px-3 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    Next
                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                    </svg>
                </a>
                @else
                <span class="relative inline-flex items-center px-3 py-2 rounded-r-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-400 cursor-not-allowed">
                    Next
                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                    </svg>
                </span>
                @endif
            </nav>
            
            {{-- Results Per Page Selector --}}
            <div class="ml-4 flex items-center">
                <label for="per_page" class="mr-2 text-sm text-gray-600">Show:</label>
                <select id="per_page" name="per_page" 
                        onchange="window.location.href='?q={{ urlencode($query) }}&type={{ $type }}&page=1&per_page=' + this.value"
                        class="border border-gray-300 rounded-md text-sm px-3 py-1 focus:outline-none focus:border-blue-500">
                    <option value="10" {{ $pagination['per_page'] == 10 ? 'selected' : '' }}>10</option>
                    <option value="20" {{ $pagination['per_page'] == 20 ? 'selected' : '' }}>20</option>
                    <option value="50" {{ $pagination['per_page'] == 50 ? 'selected' : '' }}>50</option>
                </select>
                <span class="ml-2 text-sm text-gray-600">per page</span>
            </div>
        </div>
        
        <div class="mt-4 text-center text-sm text-gray-500">
            Showing {{ ($pagination['current_page'] - 1) * $pagination['per_page'] + 1 }} to 
            {{ min($pagination['current_page'] * $pagination['per_page'], $pagination['total']) }} of 
            {{ number_format($pagination['total']) }} results
        </div>
        @endif
        
        @if(count($results['web']) === 0 && !isset($results['ecosystem']) && !isset($results['ai_enhanced']))
            <div class="text-center py-12">
                <div class="text-gray-300 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <p class="text-gray-500 text-lg font-medium">No results found for "{{ e($query) }}"</p>
                <p class="text-gray-400 mt-2">Try different keywords or check your spelling</p>
            </div>
        @endif
    </div>
</div>
@endsection
