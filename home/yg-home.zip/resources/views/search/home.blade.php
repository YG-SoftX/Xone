@extends('layouts.app')

@section('title', 'YGXONE Search - Home')

@section('content')
<div class="flex flex-col items-center justify-center min-h-screen">
    <div class="text-center mb-8">
        <h1 class="text-6xl font-bold text-blue-600 mb-2">YGXONE</h1>
        <p class="text-gray-600 text-lg">Unified Search</p>
    </div>
    
    <div class="w-full max-w-2xl px-4">
        <form action="/search" method="GET" class="relative">
            <input 
                type="text" 
                name="q" 
                placeholder="Search across all YG services..."
                class="w-full px-6 py-4 text-lg border border-gray-300 rounded-full shadow-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition"
                autofocus
            >
            <button 
                type="submit"
                class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
            >
                Search
            </button>
        </form>
        
        <div class="mt-12 text-center text-sm text-gray-500">
            <p>Search across Mail, Drive, Calendar, Contacts, and more</p>
        </div>
    </div>
</div>
@endsection
