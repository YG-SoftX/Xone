<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title>@yield('title', 'YGXONE Search')</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />
    
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Scripts & Styles -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
    <style>
        [x-cloak] { display: none !important; }
    </style>
    
    @stack('styles')
</head>
<body class="font-sans antialiased bg-gray-50">
    <!-- Admin Quick Access (visible on all pages) -->
    @if(Route::is('admin.*'))
    <div class="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 text-sm">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <span><i class="fas fa-shield-alt mr-2"></i>Admin Mode</span>
            <a href="{{ route('search.home') }}" class="hover:underline">
                <i class="fas fa-arrow-left mr-1"></i>Back to Search
            </a>
        </div>
    </div>
    @endif
    
    <div class="min-h-screen">
        @yield('content')
    </div>
    
    @stack('scripts')
</body>
</html>
