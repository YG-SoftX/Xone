<?php

namespace App\Services;

use App\Models\IndexedItem;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UnifiedSearchService
{
    /**
     * Perform unified search across all services
     */
    public function search(string $query, array $filters = []): array
    {
        // Generate cache key based on query and filters
        $cacheKey = 'search:' . md5($query . ':' . json_encode($filters));
        
        // Cache results for 5 minutes to reduce database load
        return Cache::remember($cacheKey, 300, function () use ($query, $filters) {
            return $this->executeSearch($query, $filters);
        });
    }
    
    /**
     * Execute the actual search logic (called from cache closure)
     */
    private function executeSearch(string $query, array $filters = []): array
    {
        $results = [
            'web' => [],
            'ecosystem' => [],
            'suggestions' => [],
            'ai_enhanced' => null,
        ];
        
        $type = $filters['type'] ?? 'all';

        // 1. Search web content
        if ($type === 'all' || $type === 'web') {
            $results['web'] = $this->searchWeb($query);
        }
        
        // 2. Search Ecosystem (Mail, Drive, Docs, etc.)
        if (auth()->check() && $type !== 'web') {
            $results['ecosystem'] = $this->searchEcosystem($query, $type);
        }
        
        // 3. Get AI-powered suggestions
        $results['suggestions'] = $this->getAISuggestions($query);
        
        // 4. Generate AI-enhanced answer (for complex queries)
        if ($this->shouldGenerateAIAnswer($query)) {
            $results['ai_enhanced'] = $this->generateAIAnswer($query, $results);
        }
        
        // 5. Train YugaLLM with this search query (async, not cached)
        dispatch(function () use ($query, $results) {
            $this->trainAIWithSearchQuery($query, $results);
        })->onQueue('default');
        
        return $results;
    }

    
    /**
     * Search web pages — uses parameterized LIKE queries with pagination support
     */
    public function searchWeb(string $query, int $page = 1, int $perPage = 20): array
    {
        try {
            $offset = ($page - 1) * $perPage;
            
            // Get total count for pagination
            $total = DB::table('web_pages')
                ->where('title', 'LIKE', '%' . addcslashes($query, '%_\\') . '%')
                ->orWhere('content', 'LIKE', '%' . addcslashes($query, '%_\\') . '%')
                ->count();
            
            // Get paginated results
            $pages = DB::table('web_pages')
                ->where('title', 'LIKE', '%' . addcslashes($query, '%_\\') . '%')
                ->orWhere('content', 'LIKE', '%' . addcslashes($query, '%_\\') . '%')
                ->orderBy('page_rank', 'desc')
                ->skip($offset)
                ->take($perPage)
                ->get();
            
            return [
                'results' => $pages->map(fn ($page) => [
                    'type' => 'web',
                    'title' => $page->title,
                    'url' => $page->url,
                    'snippet' => $this->highlightQuery($page->snippet ?? substr($page->content, 0, 200), $query),
                    'domain' => $page->domain,
                    'favicon' => "https://www.google.com/s2/favicons?domain={$page->domain}",
                ])->toArray(),
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'last_page' => ceil($total / $perPage),
            ];
        } catch (\Exception $e) {
            \Log::error('Web search failed', ['error' => $e->getMessage()]);
            return [
                'results' => [],
                'total' => 0,
                'page' => $page,
                'per_page' => $perPage,
                'last_page' => 0,
            ];
        }
    }
    
    /**
     * Search ecosystem content using the unified index
     */
    private function searchEcosystem(string $query, string $type): array
    {
        try {
            $search = IndexedItem::search($query);

            if ($type !== 'all') {
                $search->where('service', $type);
            }

            // Ensure user only sees their own data
            if (auth()->check()) {
                $search->where('user_id', auth()->id());
            }

            $results = $search->limit(20)->get();

            return $results->map(fn ($item) => [
                'type' => $item->service,
                'title' => $item->title,
                'snippet' => $this->highlightQuery($item->snippet ?? '', $query),
                'url' => $item->url,
                'metadata' => $item->metadata,
                'icon' => $this->getServiceIcon($item->service, $item->metadata['mime_type'] ?? null),
            ])->toArray();
        } catch (\Exception $e) {
            Log::error('Ecosystem search failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Helper: Get service icon
     */
    private function getServiceIcon(string $service, ?string $mimeType = null): string
    {
        if ($service === 'drive' && $mimeType) {
            return $this->getFileIcon($mimeType);
        }

        return match ($service) {
            'mail'     => 'envelope',
            'drive'    => 'cloud',
            'docs'     => 'file-alt',
            'contacts' => 'user',
            'calendar' => 'calendar',
            'chat'     => 'comments',
            default    => 'search',
        };
    }

    
    /**
     * Get AI-powered suggestions (public method)
     */
    public function getAISuggestions(string $query): array
    {
        return [
            'history' => $this->getUserSearchHistory($query),
            'trending' => $this->getTrendingMatches($query),
            'ai' => $this->getAIPredictions($query),
        ];
    }
    
    /**
     * Get AI-powered search suggestions
     */
    private function getAIPredictions(string $query): array
    {
        $ygAiApiUrl = config('services.yg_ai.api_url');
        $apiKey = config('services.yg_ai.api_key');
        
        if (!$ygAiApiUrl || !$apiKey) {
            return $this->getKeywordSuggestions($query);
        }
        
        try {
            $safeQuery = mb_substr(strip_tags($query), 0, 200);
            $response = Http::withHeaders([
                'X-API-Key' => $apiKey,
            ])->timeout(3)->post("{$ygAiApiUrl}/", [
                'action'   => 'brain_chat',
                'question' => 'Suggest 5 related search queries for: ' . $safeQuery . '. Return each suggestion on a new line.',
                'model'    => 'default',
            ]);
            
            if ($response->successful()) {
                $data = $response->json();
                $suggestions = explode("\n", trim($data['answer'] ?? ''));
                return array_filter(array_slice($suggestions, 0, 5));
            }
        } catch (\Exception $e) {
            \Log::error('AI suggestions failed', ['error' => $e->getMessage()]);
        }
        
        // Fallback: simple keyword-based suggestions
        return $this->getKeywordSuggestions($query);
    }
    
    /**
     * Generate AI-enhanced answer for complex queries
     */
    private function generateAIAnswer(string $query, array $results): ?array
    {
        if ($this->isNavigationalQuery($query)) {
            return null;
        }
        
        $ygAiApiUrl = config('services.yg_ai.api_url');
        $apiKey = config('services.yg_ai.api_key');
        
        if (!$ygAiApiUrl || !$apiKey) {
            return null;
        }
        
        try {
            // Gather context from top results — strip HTML tags to prevent injection
            $context = collect($results['web'])
                ->take(3)
                ->map(fn ($r) => strip_tags($r['snippet'] ?? ''))
                ->implode("\n\n");

            $safeQuery = mb_substr(strip_tags($query), 0, 200);

            $response = Http::withHeaders([
                'X-API-Key' => $apiKey,
            ])->timeout(5)->post("{$ygAiApiUrl}/", [
                'action'   => 'brain_chat',
                'question' => 'Based on this information: ' . $context . "\n\nAnswer this question concisely in 2-3 sentences: " . $safeQuery,
                'model'    => 'default',
            ]);
            
            if ($response->successful()) {
                $data = $response->json();
                return [
                    'answer' => $data['answer'],
                    'sources' => collect($results['web'])->take(3)->pluck('url')->toArray(),
                ];
            }
        } catch (\Exception $e) {
            \Log::error('AI answer generation failed', ['error' => $e->getMessage()]);
        }
        
        return null;
    }
    
    /**
     * Train YugaLLM with search query data
     */
    private function trainAIWithSearchQuery(string $query, array $results): void
    {
        // Log search query for training
        try {
            DB::table('search_training_data')->insert([
                'query' => $query,
                'result_count' => collect($results)->sum(fn ($r) => is_array($r) ? count($r) : 0),
                'had_clicks' => false,
                'session_id' => session()->getId(),
                'user_id' => auth()->id(),
                'created_at' => now(),
            ]);
        } catch (\Exception $e) {
            \Log::error('Failed to log search training data', ['error' => $e->getMessage()]);
        }
        
        // If user is authenticated, update search patterns
        if (auth()->check()) {
            try {
                DB::table('user_search_patterns')->updateOrInsert(
                    ['user_id' => auth()->id(), 'query_pattern' => $this->extractPattern($query)],
                    ['frequency' => DB::raw('frequency + 1'), 'last_searched' => now()]
                );
            } catch (\Exception $e) {
                \Log::error('Failed to update search patterns', ['error' => $e->getMessage()]);
            }
        }
        
        // Asynchronously send to YugaLLM for incremental learning
        dispatch(function () use ($query, $results) {
            $this->sendToYugaLLMTraining($query, $results);
        })->onQueue('default');
    }
    
    /**
     * Send search data to YugaLLM for training
     */
    private function sendToYugaLLMTraining(string $query, array $results): void
    {
        $ygAiApiUrl = config('services.yg_ai.api_url');
        $apiKey = config('services.yg_ai.api_key');
        
        if (!$ygAiApiUrl || !$apiKey) {
            return;
        }
        
        // Prepare training data from search results
        $trainingText = $this->prepareTrainingText($query, $results);
        
        try {
            Http::withHeaders([
                'X-API-Key' => $apiKey,
            ])->timeout(5)->post("{$ygAiApiUrl}/", [
                'action' => 'learn_text',
                'text' => $trainingText,
                'model' => 'default',
            ]);
        } catch (\Exception $e) {
            \Log::error('YugaLLM training failed', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * Prepare training text from search results
     */
    private function prepareTrainingText(string $query, array $results): string
    {
        $text = "Search Query: {$query}\n\n";
        $text .= "Top Results:\n";
        
        foreach (collect($results['web'])->take(5) as $result) {
            $text .= "- {$result['title']}: {$result['snippet']}\n";
        }
        
        $text .= "\nRelated Searches:\n";
        foreach ($results['suggestions'] as $suggestion) {
            $text .= "- {$suggestion}\n";
        }
        
        return $text;
    }
    
    /**
     * Highlight search query in text
     */
    private function highlightQuery(string $text, string $query): string
    {
        $pattern = '/(' . preg_quote($query, '/') . ')/i';
        return preg_replace($pattern, '<mark>$1</mark>', $text);
    }
    
    /**
     * Get keyword-based suggestions (fallback)
     */
    private function getKeywordSuggestions(string $query): array
    {
        $words = explode(' ', $query);
        $suggestions = [];
        
        // Common search patterns
        $patterns = [
            "how to {$query}",
            "{$query} tutorial",
            "{$query} guide",
            "best {$query}",
            "{$query} examples",
        ];
        
        return array_slice($patterns, 0, 5);
    }
    
    /**
     * Check if query should generate AI answer
     */
    private function shouldGenerateAIAnswer(string $query): bool
    {
        // Don't generate for navigational queries
        if ($this->isNavigationalQuery($query)) {
            return false;
        }
        
        // Generate for questions or how-to queries
        return preg_match('/^(what|how|why|when|where|who|can|does|is|are)/i', $query);
    }
    
    /**
     * Check if query is navigational (looking for specific site)
     */
    private function isNavigationalQuery(string $query): bool
    {
        return preg_match('/^(login|signin|signup|register|dashboard|admin)/i', $query);
    }
    
    /**
     * Extract search pattern for personalization
     */
    private function extractPattern(string $query): string
    {
        // Normalize query to pattern (e.g., "how to deploy laravel" -> "how to *")
        $words = explode(' ', strtolower($query));
        
        if (count($words) > 3) {
            return $words[0] . ' ' . $words[1] . ' *';
        }
        
        return $query;
    }
    
    /**
     * Helper: Get MIME type label
     */
    private function getMimeTypeLabel(string $mimeType): string
    {
        $types = [
            'application/pdf' => 'PDF Document',
            'image/jpeg' => 'JPEG Image',
            'image/png' => 'PNG Image',
            'text/plain' => 'Text File',
            'application/msword' => 'Word Document',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'Word Document',
        ];
        
        return $types[$mimeType] ?? 'File';
    }
    
    /**
     * Helper: Get file icon
     */
    private function getFileIcon(string $mimeType): string
    {
        if (str_contains($mimeType, 'pdf')) return 'file-pdf';
        if (str_contains($mimeType, 'image')) return 'file-image';
        if (str_contains($mimeType, 'word')) return 'file-word';
        if (str_contains($mimeType, 'excel') || str_contains($mimeType, 'spreadsheet')) return 'file-excel';
        return 'file';
    }
    
    /**
     * Helper: Format bytes to human-readable
     */
    private function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
}
