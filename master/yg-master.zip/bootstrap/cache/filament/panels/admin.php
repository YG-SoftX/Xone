<?php return array (
  'livewireComponents' => 
  array (
    'App\\Filament\\Resources\\AppModules\\Pages\\CreateAppModule' => 'App\\Filament\\Resources\\AppModules\\Pages\\CreateAppModule',
    'App\\Filament\\Resources\\AppModules\\Pages\\EditAppModule' => 'App\\Filament\\Resources\\AppModules\\Pages\\EditAppModule',
    'App\\Filament\\Resources\\AppModules\\Pages\\ListAppModules' => 'App\\Filament\\Resources\\AppModules\\Pages\\ListAppModules',
    'App\\Filament\\Resources\\AuditLogs\\Pages\\CreateAuditLog' => 'App\\Filament\\Resources\\AuditLogs\\Pages\\CreateAuditLog',
    'App\\Filament\\Resources\\AuditLogs\\Pages\\EditAuditLog' => 'App\\Filament\\Resources\\AuditLogs\\Pages\\EditAuditLog',
    'App\\Filament\\Resources\\AuditLogs\\Pages\\ListAuditLogs' => 'App\\Filament\\Resources\\AuditLogs\\Pages\\ListAuditLogs',
    'App\\Filament\\Resources\\Developers\\Pages\\CreateDeveloper' => 'App\\Filament\\Resources\\Developers\\Pages\\CreateDeveloper',
    'App\\Filament\\Resources\\Developers\\Pages\\EditDeveloper' => 'App\\Filament\\Resources\\Developers\\Pages\\EditDeveloper',
    'App\\Filament\\Resources\\Developers\\Pages\\ListDevelopers' => 'App\\Filament\\Resources\\Developers\\Pages\\ListDevelopers',
    'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\CreateInfrastructureNode' => 'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\CreateInfrastructureNode',
    'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\EditInfrastructureNode' => 'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\EditInfrastructureNode',
    'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\ListInfrastructureNodes' => 'App\\Filament\\Resources\\InfrastructureNodes\\Pages\\ListInfrastructureNodes',
    'App\\Filament\\Resources\\MobileDevices\\Pages\\CreateMobileDevice' => 'App\\Filament\\Resources\\MobileDevices\\Pages\\CreateMobileDevice',
    'App\\Filament\\Resources\\MobileDevices\\Pages\\EditMobileDevice' => 'App\\Filament\\Resources\\MobileDevices\\Pages\\EditMobileDevice',
    'App\\Filament\\Resources\\MobileDevices\\Pages\\ListMobileDevices' => 'App\\Filament\\Resources\\MobileDevices\\Pages\\ListMobileDevices',
    'App\\Filament\\Resources\\PaymentProfiles\\Pages\\CreatePaymentProfile' => 'App\\Filament\\Resources\\PaymentProfiles\\Pages\\CreatePaymentProfile',
    'App\\Filament\\Resources\\PaymentProfiles\\Pages\\EditPaymentProfile' => 'App\\Filament\\Resources\\PaymentProfiles\\Pages\\EditPaymentProfile',
    'App\\Filament\\Resources\\PaymentProfiles\\Pages\\ListPaymentProfiles' => 'App\\Filament\\Resources\\PaymentProfiles\\Pages\\ListPaymentProfiles',
    'App\\Filament\\Resources\\Subscriptions\\Pages\\CreateSubscription' => 'App\\Filament\\Resources\\Subscriptions\\Pages\\CreateSubscription',
    'App\\Filament\\Resources\\Subscriptions\\Pages\\EditSubscription' => 'App\\Filament\\Resources\\Subscriptions\\Pages\\EditSubscription',
    'App\\Filament\\Resources\\Subscriptions\\Pages\\ListSubscriptions' => 'App\\Filament\\Resources\\Subscriptions\\Pages\\ListSubscriptions',
    'App\\Filament\\Resources\\Tenants\\Pages\\CreateTenant' => 'App\\Filament\\Resources\\Tenants\\Pages\\CreateTenant',
    'App\\Filament\\Resources\\Tenants\\Pages\\EditTenant' => 'App\\Filament\\Resources\\Tenants\\Pages\\EditTenant',
    'App\\Filament\\Resources\\Tenants\\Pages\\ListTenants' => 'App\\Filament\\Resources\\Tenants\\Pages\\ListTenants',
    'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\CreateThirdPartyApp' => 'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\CreateThirdPartyApp',
    'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\EditThirdPartyApp' => 'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\EditThirdPartyApp',
    'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\ListThirdPartyApps' => 'App\\Filament\\Resources\\ThirdPartyApps\\Pages\\ListThirdPartyApps',
    'App\\Filament\\Resources\\Users\\Pages\\CreateUser' => 'App\\Filament\\Resources\\Users\\Pages\\CreateUser',
    'App\\Filament\\Resources\\Users\\Pages\\EditUser' => 'App\\Filament\\Resources\\Users\\Pages\\EditUser',
    'App\\Filament\\Resources\\Users\\Pages\\ListUsers' => 'App\\Filament\\Resources\\Users\\Pages\\ListUsers',
    'Filament\\Pages\\Dashboard' => 'Filament\\Pages\\Dashboard',
    'App\\Filament\\Widgets\\EcosystemStatsWidget' => 'App\\Filament\\Widgets\\EcosystemStatsWidget',
    'App\\Filament\\Widgets\\RevenueChartWidget' => 'App\\Filament\\Widgets\\RevenueChartWidget',
    'Filament\\Widgets\\AccountWidget' => 'Filament\\Widgets\\AccountWidget',
    'Filament\\Widgets\\FilamentInfoWidget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'Filament\\Livewire\\DatabaseNotifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'Filament\\Auth\\Pages\\EditProfile' => 'Filament\\Auth\\Pages\\EditProfile',
    'Filament\\Livewire\\GlobalSearch' => 'Filament\\Livewire\\GlobalSearch',
    'Filament\\Livewire\\Notifications' => 'Filament\\Livewire\\Notifications',
    'Filament\\Livewire\\Sidebar' => 'Filament\\Livewire\\Sidebar',
    'Filament\\Livewire\\SimpleUserMenu' => 'Filament\\Livewire\\SimpleUserMenu',
    'Filament\\Livewire\\Topbar' => 'Filament\\Livewire\\Topbar',
    'Filament\\Auth\\Pages\\Login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageConfigurations' => 
  array (
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\AppModules\\AppModuleResource.php' => 'App\\Filament\\Resources\\AppModules\\AppModuleResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\AuditLogs\\AuditLogResource.php' => 'App\\Filament\\Resources\\AuditLogs\\AuditLogResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\Developers\\DeveloperResource.php' => 'App\\Filament\\Resources\\Developers\\DeveloperResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\InfrastructureNodes\\InfrastructureNodeResource.php' => 'App\\Filament\\Resources\\InfrastructureNodes\\InfrastructureNodeResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\MobileDevices\\MobileDeviceResource.php' => 'App\\Filament\\Resources\\MobileDevices\\MobileDeviceResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\PaymentProfiles\\PaymentProfileResource.php' => 'App\\Filament\\Resources\\PaymentProfiles\\PaymentProfileResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\Subscriptions\\SubscriptionResource.php' => 'App\\Filament\\Resources\\Subscriptions\\SubscriptionResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\Tenants\\TenantResource.php' => 'App\\Filament\\Resources\\Tenants\\TenantResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\ThirdPartyApps\\ThirdPartyAppResource.php' => 'App\\Filament\\Resources\\ThirdPartyApps\\ThirdPartyAppResource',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Resources\\Users\\UserResource',
  ),
  'resourceConfigurations' => 
  array (
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Widgets\\EcosystemStatsWidget.php' => 'App\\Filament\\Widgets\\EcosystemStatsWidget',
    'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament\\Widgets\\RevenueChartWidget.php' => 'App\\Filament\\Widgets\\RevenueChartWidget',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\ASUS\\Downloads\\YG Soft1\\Core\\yg-master\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);