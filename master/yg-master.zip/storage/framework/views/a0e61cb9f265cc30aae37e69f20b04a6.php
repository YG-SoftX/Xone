<p
    <?php echo e($attributes->class(['fi-modal-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\ASUS\Downloads\YG Soft1\Core\yg-master\vendor\filament\support\resources\views\components\modal\description.blade.php ENDPATH**/ ?>