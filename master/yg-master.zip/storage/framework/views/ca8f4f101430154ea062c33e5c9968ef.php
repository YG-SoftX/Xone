<?php echo value($html); ?>

<?php /**PATH C:\Users\ASUS\Downloads\YG Soft1\Core\yg-master\vendor\filament\support\resources\views\anonymous-partial.blade.php ENDPATH**/ ?>