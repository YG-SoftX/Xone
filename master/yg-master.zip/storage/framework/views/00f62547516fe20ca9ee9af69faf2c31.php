<h2
    <?php echo e($attributes->class(['fi-modal-heading'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\Users\ASUS\Downloads\YG Soft1\Core\yg-master\vendor\filament\support\resources\views\components\modal\heading.blade.php ENDPATH**/ ?>