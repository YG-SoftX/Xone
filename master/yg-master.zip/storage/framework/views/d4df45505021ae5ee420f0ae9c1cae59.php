<p
    <?php echo e($attributes->class(['fi-section-header-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\ASUS\Downloads\YG Soft1\Core\yg-master\vendor\filament\support\resources\views\components\section\description.blade.php ENDPATH**/ ?>