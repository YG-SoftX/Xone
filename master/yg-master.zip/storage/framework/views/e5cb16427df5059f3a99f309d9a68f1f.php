<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH C:\Users\ASUS\Downloads\YG Soft1\Core\yg-master\vendor\filament\support\resources\views\components\loading-indicator.blade.php ENDPATH**/ ?>