<?php

namespace App\Filament\Widgets;

use App\Models\Subscription;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Carbon;

class RevenueChartWidget extends ChartWidget
{
    protected ?string $heading = 'Monthly Recurring Revenue (MRR)';
    protected static ?int $sort = 2;
    public ?string $filter = '6';

    protected function getFilters(): ?array
    {
        return [
            '3'  => 'Last 3 months',
            '6'  => 'Last 6 months',
            '12' => 'Last 12 months',
        ];
    }

    protected function getData(): array
    {
        $months = (int) ($this->filter ?? 6);

        $labels  = [];
        $mrr     = [];
        $newSubs = [];

        for ($i = $months - 1; $i >= 0; $i--) {
            $date     = Carbon::now()->subMonths($i);
            $labels[] = $date->format('M Y');

            // Active subs that existed this month (created before end, not expired before start)
            $active = Subscription::where('status', 'active')
                ->where('created_at', '<=', $date->copy()->endOfMonth())
                ->where(function ($q) use ($date) {
                    $q->whereNull('expires_at')
                      ->orWhere('expires_at', '>=', $date->copy()->startOfMonth());
                })
                ->count();

            // Estimated MRR: count × $10 average plan price
            $mrr[] = $active * 10;

            // New subscriptions this calendar month
            $newSubs[] = Subscription::whereYear('created_at', $date->year)
                ->whereMonth('created_at', $date->month)
                ->count();
        }

        return [
            'datasets' => [
                [
                    'label'           => 'MRR ($)',
                    'data'            => $mrr,
                    'backgroundColor' => 'rgba(244, 63, 94, 0.15)',
                    'borderColor'     => '#e11d48',
                    'fill'            => true,
                    'tension'         => 0.4,
                ],
                [
                    'label'           => 'New Subscriptions',
                    'data'            => $newSubs,
                    'backgroundColor' => 'rgba(59, 130, 246, 0.15)',
                    'borderColor'     => '#3b82f6',
                    'fill'            => false,
                    'tension'         => 0.4,
                ],
            ],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }
}
