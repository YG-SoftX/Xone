<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

// 🛡️ Sovereign Emergency Triggers (PUBLIC - DELETE AFTER USE)
Route::get('/migrate', function () {
    try {
        Artisan::call('migrate', ['--force' => true]);
        return response()->json([
            'status' => 'success',
            'message' => 'Empire migrations executed.',
            'output' => Artisan::output()
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => $e->getMessage()
        ], 500);
    }
});

Route::get('/seed', function () {
    try {
        Artisan::call('db:seed', ['--class' => 'NavigationSeeder', '--force' => true]);
        return response()->json([
            'status' => 'success',
            'message' => 'Sovereign navigation seeded.',
            'output' => Artisan::output()
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => $e->getMessage()
        ], 500);
    }
});

Route::get('/', function () {
    return redirect('/admin');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/guardian/dashboard', [\App\Http\Controllers\GuardianController::class, 'index'])->name('guardian.dashboard');
    
    Route::prefix('admin/ai-training')->group(function () {
        Route::get('/', [\App\Http\Controllers\AiTrainingController::class, 'index'])->name('ai-training.index');
        Route::post('/clear', [\App\Http\Controllers\AiTrainingController::class, 'clear'])->name('ai-training.clear');
    });
});

